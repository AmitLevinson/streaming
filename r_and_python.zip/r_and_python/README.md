## R Vs Python

A repository containing the files for the live stream.

`full_data/` — Folder containing the original file and and a `clean.csv`, the original with translating the names and adding a random DOB column.

`split_data/` — Folder containing the `.csv` files we'll read in as part of showcasing how to load multiple files.

**Either follow along the stream to load the split files, or dive write in with the `clean.csv`.**