library(purrr)
library(dplyr)
library(readr)
library(tidyr)
library(ggplot2)

# 1. Load data ------------------------------------------------------------
files <- paste0("split_data/", list.files("split_data"))
dogs <- map_dfr(files, read_csv, col_types = cols())


# 2. Skim data ------------------------------------------------------------
skimr::skim(dogs)


# 3. Frequent colors ---------------------------------------------------------

split_colors <- dogs %>% 
  mutate(
    new_dog_color = strsplit(dog_color, split = "/"),
    .before = age
  ) %>% 
  unnest_longer(new_dog_color)
  
split_colors %>% 
  count(new_dog_color, sort = T)


# 4. Common dogs for each gender ---------------------------------------------

dogs %>% 
  count(dog_gender, primary_breed, sort = T) %>% 
  group_by(dog_gender) %>% 
  slice(1:10) %>% 
  ungroup() %>% 
  ggplot(aes(x= n, y = tidytext::reorder_within(primary_breed,n, dog_gender ))) +
  geom_col() +
  facet_wrap(vars(dog_gender), scales = "free") +
  tidytext::scale_y_reordered()
  

# 5. age gap --------------------------------------------------------------

dat %>% 
  group_by(owner_id) %>% 
  filter(n() > 1,
         dog_dob == max(dog_dob) | dog_dob == min(dog_dob)) %>%
  # filter(owner_id == 89433 ) 
  select(owner_id, dog_dob) %>%
  arrange(owner_id, dog_dob) %>% 
  mutate(datediff = difftime(dog_dob, lag(dog_dob, default = NA), units = "weeks")) %>% 
  fill(datediff, .direction = "up") %>% 
  arrange(-datediff)


# 8. save file as multiple sheets by age group ----------------------------

dat %>% 
  split(.$age) %>% 
  openxlsx::write.xlsx(., file = "dogs_by_owner_age.xlsx")

